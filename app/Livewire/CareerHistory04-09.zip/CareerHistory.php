<?php

namespace App\Livewire;

use Livewire\Component;
use App\Models\CertificateType;
use App\Models\CertificateIssuer;

class CareerHistory extends Component
{
    public $showAddDocumentModal = false;
    
    // Certificate Types
    public $certificateTypes = [];
    public $selectedCertificateType;

    // Certificate Issuers
    public $certificateIssuers = [];
    public $selectedCertificateIssuer;

    public function mount()
    {
        // Load active certificate types
        $this->certificateTypes = CertificateType::where('is_active', true)
            ->orderBy('name')
            ->get();

        // Load active certificate issuers
        $this->certificateIssuers = CertificateIssuer::where('is_active', true)
            ->orderBy('name')
            ->get();
    }

    public function showModal()
    {
        $this->showAddDocumentModal = true;
    }

    public function closeModal()
    {
        $this->showAddDocumentModal = false;
    }

    public function render()
    {
        return view('livewire.career-history')->layout('layouts.app'); 
    }
}



// Render your existing Blade view:
        // return view('career-history')
        //     ->layout('layouts.app'); // Jetstream: uses <x-app-layout>, optional