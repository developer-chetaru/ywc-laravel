<div class="mt-2 text-pink-800 font-medium">
    @error($id) {{ $message }} @enderror
</div>
