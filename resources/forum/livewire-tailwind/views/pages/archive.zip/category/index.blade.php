<div>
    @role('super_admin')
    <div class="flex">
        <div class="grow"></div>
        <div>
            @can ('createCategories')
                <x-forum::link-button
                    :label="trans('forum::categories.create')"
                    icon="squares-plus-outline"
                    :href="Forum::route('category.create')"
                    class="link-button inline-block rounded-md font-regular text-md text-center text-white bg-blue-600 hover:text-white hover:bg-blue-500 min-w-36 px-4 py-2" />
            @endcan
        </div>
    </div>
    @endrole

    <div>
        @role('super_admin')
            <main class="flex-1">
                <div class="flex h-[calc(100vh-160px)] gap-x-[24px] bg-gray-100 mt-4">

                    <!-- Left Sidebar -->
                    <div class="w-90 bg-white rounded-xl flex flex-col">
                        <div class="p-4">
                            <!-- Search -->
                            <div class="flex items-center gap-2 mb-4">
                                <form class="relative flex-1" action="">
                                    <input type="search" placeholder="Search Topics"
                                        class="w-full py-3 px-4 rounded-lg border border-gray-200 focus:outline-none focus:border focus:!border-blue-200 text-sm !pl-[40px] font-medium !bg-[#F8F9FA]" />
                                    <button class="!absolute !left-3 !top-1/2 !transform !-translate-y-1/2" type="submit">
                                        <img src="{{ asset('images/search.svg') }}" alt="">
                                    </button>
                                </form>
                                <button class="py-3 px-4 border border-gray-200 rounded-lg !bg-[#F8F9FA] hover:bg-gray-200">
                                    <img src="{{ asset('images/filter.svg') }}" alt="">
                                </button>
                            </div>

                            <!-- Tabs -->
                            <div class="flex mb-4 justify-center">
                                <button
                                    class="flex-1 tab-btn border-b border-gray-200 px-4 py-2 text-sm {{ $activeTab === 'forum-list' ? '!border-b-[2px] !border-blue-600 text-blue-600 font-regular' : 'text-gray-500' }}"
                                    wire:click="$set('activeTab', 'forum-list')"
                                    data-target="forum-list">
                                    Forum List
                                </button>

                                <button
                                    class="flex-1 tab-btn border-b border-gray-200 px-4 py-2 text-sm {{ $activeTab === 'user-requests' ? '!border-b-[2px] !border-blue-600 text-blue-600 font-regular' : 'text-gray-500' }}"
                                    wire:click="$set('activeTab', 'user-requests')"
                                    data-target="user-requests">
                                    User Requests
                                    <span class="ml-1 text-xs bg-red-500 text-white rounded-full px-2">
                                        {{ $pendingRequestsCount }}
                                    </span>
                                </button>

                            </div>
                        </div>

                        <!-- Forum List -->
                        <nav id="forum-list" class="tab-content {{ $activeTab !== 'forum-list' ? 'hidden' : '' }} flex-1 overflow-y-auto px-0 pb-4 [scrollbar-width:none]">
                            <div>
                                @foreach($categories as $category)
                                    <div class="mb-5 pb-4">
                                        <h4 class="font-medium text-[#808080] mb-[13px] hover:text-[#1B1B1B] flex justify-between gap-2 items-start cursor-pointer px-5 !pl-[40px]"
                                            onclick="toggleSection(this)">
                                            
                                            <div class="flex flex-col">
                                                <span class="capitalize">{{ $category->title }}</span>

                                                <div class="flex items-center gap-4 text-xs text-gray-500 mt-3">
                                                    {{-- Chat Icon + Thread Count --}}
                                                    <p class="flex items-center gap-1 text-sm">
                                                        <img src="{{ asset('images/wechat.svg') }}" alt="Chat Icon" class="w-4 h-4" />
                                                        <span>{{ $category->threads()->count() ?? 0 }}</span>
                                                    </p>

                                                    {{-- Calendar Icon + Created Date --}}
                                                    <p class="flex items-center gap-1 text-sm">
                                                        <img src="{{ asset('images/calendar-03.svg') }}" alt="Calendar Icon" class="w-4 h-4" />
                                                        <span>{{ $category->created_at->format('M d, Y') }}</span>
                                                    </p>
                                                </div>
                                            </div>

                                            <!-- Arrow icon -->
                                            <img src="{{ asset('images/down-arr.svg') }}" 
                                                alt="Expand Icon" 
                                                class="w-3 h-5 transition-transform duration-200 arrow-icon" />
                                        </h4>

                                        <div class="hidden section-content">
                                            @if ($category->accepts_threads && $category->threads->count())
                                                <ol class="text-[#808080] mt-6 space-y-2 font-medium text-[16px]">
                                                    @foreach($category->threads as $index => $thread)
                                                        <li class="group p-3 pl-[25px] hover:bg-[#F8F9FA] rounded-lg border border-transparent hover:!border-[#E5E5E5] flex items-start gap-2 mx-5">
                                                            <span class="text-[#808080] ">{{ $index + 1 }}.</span>
                                                            <a href="javascript:void(0);" 
                                                            wire:click="loadThread({{ $thread->id }})" 
                                                            class="!text-[#808080]  capitalize">
                                                                {{ $thread->title }}
                                                            </a>
                                                        </li>
                                                    @endforeach
                                                </ol>
                                            @else
                                                <p class="text-gray-400 text-sm mt-2">No threads available</p>
                                            @endif
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        </nav>

                        <!-- User Requests -->
                        <nav id="user-requests" class="tab-content {{ $activeTab !== 'user-requests' ? 'hidden' : '' }} overflow-y-auto px-4 pb-4 pl-[30px] [scrollbar-width:none]">
                            <div class="p-4 mb-2 !px-0 border-b flex justify-between items-center">
                                <h4 class="font-semibold text-lg text-gray-700">User Discussion Requests</h4>
                                <span class="ml-1 text-xs bg-red-500 text-white rounded-full px-2">
                                    {{ $pendingRequestsCount }}
                                </span>
                            </div>

                            <div class="flex-1 overflow-y-auto">
                                @if($userRequests->count())
                                    <ul class="divide-y divide-gray-200">
                                        @foreach($userRequests as $request)
                                            <li class="group p-2 rounded-lg hover:bg-gray-50 flex justify-between items-center border border-transparent hover:!border-[#E5E5E5]">
                                                <div class="flex flex-col">
                                                    <span class="font-medium text-gray-800">
                                                        {{ $request->user->first_name }} {{ $request->user->last_name }}
                                                    </span>
                                                    <span class="text-sm text-gray-500">
                                                        Thread: {{ $request->thread->title ?? 'N/A' }}
                                                    </span>
                                                    <!-- <span class="text-xs text-gray-400 mt-1">
                                                        Status: {{ ucfirst($request->status) }}
                                                    </span> -->
                                                </div>

                                                <div class="flex gap-2">
                                                    @if($request->status === 'pending')
                                                        <button wire:click.prevent="approveRequest({{ $request->id }})"
                                                            class="px-3 py-1 bg-blue-500 text-white rounded-md text-sm hover:bg-blue-600 cursor-pointer">
                                                            Approve
                                                        </button>

                                                        <button wire:click.prevent="rejectRequest({{ $request->id }})"
                                                            class="px-3 py-1 bg-red-500 text-white rounded-md text-sm hover:bg-red-600 cursor-pointer">
                                                            Reject
                                                        </button>
                                                    @else
                                                        <span class="text-xs px-2 py-1 rounded bg-gray-200">
                                                            {{ ucfirst($request->status) }}
                                                        </span>
                                                    @endif
                                                </div>
                                            </li>
                                        @endforeach
                                    </ul>
                                @else
                                    <div class="p-4 text-gray-500">
                                        No user requests found.
                                    </div>
                                @endif
                            </div>
                        </nav>


                    </div>

                    <!-- Right Content -->
                    <section id="main-content" class="flex-1 flex flex-col bg-white rounded-xl shadow-sm !p-0 md:p-8">
                        @if($selectedThread)
                            <div x-data="{ threadKey: '{{ $selectedThread->id }}-{{ Str::random(8) }}' }"
                                x-init="$watch('selectedThread', value => {
                                    threadKey = '{{ $selectedThread->id }}-' + Math.random().toString(36).substring(2, 10);
                                })"
                                @request-updated.window="if ($event.detail.threadId === {{ $selectedThread->id }}) {
                                    threadKey = '{{ $selectedThread->id }}-' + Math.random().toString(36).substring(2, 10);
                                }">
                                @livewire('forum::categories.thread-view', ['threadId' => $selectedThread->id], key($selectedThread->id . '-' . Str::random(8)))
                            </div>
                        @else
                            <div id="welcome-section" class="flex flex-col items-center justify-center h-full text-center">
                                <div class="bg-blue-600 rounded-full mb-6 shadow-lg">
                                    <img src="{{ asset('images/department-forums-image-02-blue.svg') }}" class="w-[80px] h-[80px] text-white" alt="WeChat Icon" />
                                </div>
                                <h1 class="text-3xl font-semibold text-blue-600 mb-2">
                                    Welcome to Department Forums
                                </h1>
                            </div>
                        @endif
                    </section>
                </div>
            </main>
        @endrole
    </div>

    @role('user')
    <div>
        <main class="flex-1">
            <div class="flex user-forum h-[calc(100vh-100px)] gap-x-[24px] bg-gray-100">

                <!-- Left Sidebar -->
                <div class="w-90 bg-white rounded-xl flex flex-col">
                    <div class="p-4">
                        <!-- Search -->
                        <div class="flex items-center gap-2 mb-4">
                            <form class="relative flex-1" action="">
                                <input type="search" placeholder="Search Topics"
                                    class="w-full py-3 px-4 rounded-lg border border-gray-200 focus:outline-none focus:border focus:!border-blue-200 text-sm !pl-[40px] font-medium !bg-[#F8F9FA]" />
                                <button class="!absolute !left-3 !top-1/2 !transform !-translate-y-1/2" type="submit">
                                    <img src="{{ asset('images/search.svg') }}" alt="">
                                </button>
                            </form>
                        </div>
                    </div>

                    <!-- Forum List -->
                    <nav class="flex-1 overflow-y-auto px-0 pb-4 [scrollbar-width:none]">
                        @foreach($categories as $category)
                            <div class="mb-5 pb-4">
                                <h4 class="font-medium text-[#808080] mb-[13px] hover:text-[#1B1B1B] flex justify-between gap-2 items-start cursor-pointer px-5 !pl-[40px]"
                                    onclick="toggleSection(this)">
                                    
                                    <div class="flex flex-col">
                                        <span class="capitalize">{{ $category->title }}</span>

                                        <div class="flex items-center gap-4 text-xs text-gray-500 mt-3">
                                            {{-- Chat Icon + Thread Count --}}
                                            <p class="flex items-center gap-1 text-sm">
                                                <img src="{{ asset('images/wechat.svg') }}" alt="Chat Icon" class="w-4 h-4" />
                                                <span>{{ $category->threads()->count() ?? 0 }}</span>
                                            </p>

                                            {{-- Calendar Icon + Created Date --}}
                                            <p class="flex items-center gap-1 text-sm">
                                                <img src="{{ asset('images/calendar-03.svg') }}" alt="Calendar Icon" class="w-4 h-4" />
                                                <span>{{ $category->created_at->format('M d, Y') }}</span>
                                            </p>
                                        </div>
                                    </div>

                                    <!-- Arrow icon -->
                                    <img src="{{ asset('images/down-arr.svg') }}" 
                                        alt="Expand Icon" 
                                        class="w-3 h-5 transition-transform duration-200 arrow-icon" />
                                </h4>

                                <div class="hidden section-content">
                                    @if ($category->accepts_threads && $category->threads->count())
                                        <ol class="text-[#808080] mt-6 space-y-2 font-medium text-[16px]">
                                            @foreach($category->threads as $index => $thread)
                                                @php
                                                    $userRequest = auth()->check()
                                                        ? \App\Models\UserRequest::where('user_id', auth()->id())
                                                            ->where('thread_id', $thread->id)
                                                            ->latest()
                                                            ->first()
                                                        : null;

                                                    $isActive = isset($selectedThread) && $selectedThread->id === $thread->id;
                                                @endphp

                                                <li wire:key="thread-{{ $thread->id }}" 
                                                    class="group p-3 pl-[25px] hover:bg-[#F8F9FA] rounded-lg border border-transparent hover:!border-[#E5E5E5] flex items-start gap-2 mx-5">

                                                    <!-- Thread Title & Status -->
                                                    <div class="flex items-center gap-2">
                                                        <span class="text-[#808080] ">{{ $index + 1 }}.</span>

                                                        @if ($userRequest && $userRequest->status === 'approved')
                                                            <a href="javascript:void(0)" wire:click="openThread({{ $thread->id }})" class="!text-[#808080] {{ $isActive ? '!text-[#0053FF]' : 'text-blue-600' }} capitalize">
                                                                {{ $thread->title }}
                                                            </a>
                                                        @elseif ($userRequest && $userRequest->status === 'pending')
                                                            <span class="text-gray-800 cursor-not-allowed capitalize">
                                                                {{ $thread->title }}
                                                            </span>
                                                            <span class="ml-2 text-yellow-600 text-sm font-medium">Pending...</span>
                                                        @elseif ($userRequest && $userRequest->status === 'rejected')
                                                            <span class="text-gray-800 capitalize">{{ $thread->title }}</span>
                                                            <span class="ml-2 text-red-500 text-sm font-medium">Request Rejected</span>
                                                        @else
                                                            <span class="text-gray-700 capitalize">{{ $thread->title }}</span>
                                                        @endif
                                                    </div>

                                                    <!-- Request Access Button -->
                                                    @if (auth()->check() && !auth()->user()->hasRole('super_admin') && !$userRequest)
                                                        <button wire:click="requestAccess({{ $thread->id }})"
                                                                class="ml-2 px-2 py-1 text-sm bg-blue-500 text-white rounded hover:bg-blue-600">
                                                            Request Access
                                                        </button>
                                                    @endif
                                                </li>
                                            @endforeach
                                        </ol>
                                    @else
                                        <p class="text-gray-400 text-sm mt-2">No threads available</p>
                                    @endif
                                </div>
                            </div>
                        @endforeach
                    </nav>
                </div>

                <!-- Right Content -->
                <section id="main-content" class="flex-1 flex flex-col bg-white rounded-xl shadow-sm">
                    @if($selectedThread)
                        <div x-data="{ threadKey: '{{ $selectedThread->id }}-{{ Str::random(8) }}' }"
                            x-init="$watch('selectedThread', value => {
                                threadKey = '{{ $selectedThread->id }}-' + Math.random().toString(36).substring(2, 10);
                            })"
                            @request-updated.window="if ($event.detail.threadId === {{ $selectedThread->id }}) {
                                threadKey = '{{ $selectedThread->id }}-' + Math.random().toString(36).substring(2, 10);
                            }">

                            {{-- Only include this once --}}
                            @livewire('forum::categories.thread-view', ['threadId' => $selectedThread->id], key($selectedThread->id . '-' . Str::random(8)))

                        </div>
                    @else
                        <div id="welcome-section" class="flex flex-col items-center justify-center h-full text-center">
                            <div class="bg-blue-600 rounded-full mb-6 shadow-lg">
                                <img src="{{ asset('images/department-forums-image-02-blue.svg') }}" class="w-[80px] h-[80px] text-white" alt="WeChat Icon" />
                            </div>
                            <h1 class="text-3xl font-semibold text-blue-600 mb-2">
                                Welcome to Department Forums
                            </h1>
                        </div>
                    @endif
                </section>

            </div>
        </main>
    </div>
    @endrole

</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    document.addEventListener("DOMContentLoaded", () => {
        const buttons = document.querySelectorAll(".tab-btn");
        const contents = document.querySelectorAll(".tab-content");

        buttons.forEach(btn => {
            btn.addEventListener("click", () => {
                buttons.forEach(b => {
                    b.classList.remove("border-blue-600", "text-blue-600", "font-semibold");
                    b.classList.add("border-transparent", "text-gray-500");
                });

                btn.classList.add("border-blue-600", "text-blue-600", "font-semibold");
                btn.classList.remove("border-transparent", "text-gray-500");

                const target = btn.getAttribute("data-target");
                contents.forEach(c => c.classList.add("hidden"));
                document.getElementById(target).classList.remove("hidden");
            });
        });
    });

    function toggleSection(header) {
        const content = header.nextElementSibling;
        const icon = header.querySelector('.arrow-icon');

        if (content.classList.contains('hidden')) {
            content.classList.remove('hidden');
            icon.src = "{{ asset('images/arrow-up.svg') }}";
        } else {
            content.classList.add('hidden');
            icon.src = "{{ asset('images/down-arr.svg') }}";
        }
    }

    document.addEventListener("livewire:init", () => {
        Livewire.on("request-updated", (event) => {
            Swal.fire({
                title: "Success",
                text: event.message,
                icon: "success",
                timer: 2000,
                showConfirmButton: false
            });

            if (event.threadId) {
                Livewire.emit('openThread', event.threadId);

                // Force User Requests tab active
                const userRequestsTab = document.querySelector('.tab-btn[data-target="user-requests"]');
                if (userRequestsTab) {
                    userRequestsTab.click();
                }
            }
        });
    });


</script>
