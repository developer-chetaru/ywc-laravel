<x-app-layout>
   
    <div class="py-10">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">
            @livewire('profile.update-password-form')
        </div>
    </div>
</x-app-layout>
