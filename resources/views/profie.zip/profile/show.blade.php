<x-app-layout>
    <div>
        @livewire('profile.update-profile-information-form')
    </div>
    </div>
</x-app-layout>
