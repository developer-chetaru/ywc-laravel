
@role('user')
<div class="flex-1 flex flex-col overflow-hidden">
    <div class="flex min-h-screen bg-gray-100">
        <div class="flex-1 transition-all duration-300">
            <main class="p-6 flex-1 overflow-y-auto">
                <div class="w-full h-screen ">
                    <div class="bg-white p-5 rounded-lg shadow-md">
                        <h2 class="text-xl border-b border-gray-100 font-medium text-[#0053FF] pb-2">Career History</h2>
                        <div class="bg-[#F5F6FA] p-5 rounded-lg mt-6">
                            <div class="grid grid-cols-3 gap-4">
                                <div x-data="{ showModal: false }">
                                    <!-- Add Document Card -->
                                    <div class="bg-white rounded-xl p-3 py-8 flex justify-center items-center flex-col cursor-pointer"
                                        @click="showModal = true">
                                        <!-- SVG Icon -->
                                        <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M16.6601 3.36803C12.496 3.19173 9.27886 3.67143 9.27886 3.67143C7.24744 3.81668 3.35443 4.95555 3.35446 11.6067C3.35449 18.2013 3.31139 26.3313 3.35446 29.5723C3.35446 31.5525 4.58049 36.1713 8.82409 36.4188C13.9822 36.7198 23.2732 36.7838 27.5361 36.4188C28.6772 36.3545 32.4764 35.4586 32.9572 31.3251C33.4554 27.043 33.3562 24.067 33.3562 23.3586" stroke="#616161" stroke-width="2.15385" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M29.9998 3.07715V16.9233" stroke="#0053FE" stroke-width="2.15385" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M23.0769 10L36.9231 10" stroke="#0053FE" stroke-width="2.15385" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M11.6346 21.6943H18.3013" stroke="#616161" stroke-width="2.15385" stroke-linecap="round"/>
                                        <path d="M11.6346 28.3652H24.9679" stroke="#616161" stroke-width="2.15385" stroke-linecap="round"/>
                                        </svg>
                                        <h4 class="mt-2">Add Document</h4>
                                    </div>


                                    <div 
                                        x-show="showModal" 
                                        class="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm" 
                                        x-transition
                                        x-data="{
                                            docType: '',
                                            certificateRows: [{ type:'', issue:'', expiry:'' }],
                                            searchIssuer: '',
                                            fileName: '',
                                            previewUrl: '',
                                            isPdf: false,
                                            resetForm() {
                                                this.docType = '';
                                                this.certificateRows = [{ type:'', issue:'', expiry:'' }];
                                                this.searchIssuer = '';
                                                this.fileName = '';
                                                this.previewUrl = '';
                                                this.isPdf = false;
                                            }
                                        }"
                                    >
                                        <div class="bg-white rounded-lg shadow-lg w-[90%] h-[90%] max-w-6xl p-6 relative overflow-y-auto">

                                            <!-- Close Button -->
                                            <button 
                                                @click="resetForm(); showModal = false" 
                                                class="absolute top-4 right-4 text-gray-500 hover:text-gray-700 text-2xl">
                                                &times;
                                            </button>

                                            <h2 class="text-2xl font-bold text-[#0053FF] mb-6">Add Document</h2>

                                            <div class="grid grid-cols-2 gap-6">
                                                <!-- Left side: Upload area -->
                                                <div class="border-dashed border-2 border-gray-300 rounded-lg p-6 flex items-center justify-center text-center cursor-pointer relative overflow-hidden"
                                                    x-data="{
                                                        isDragging: false, 
                                                        fileName: '', 
                                                        previewUrl: '', 
                                                        isPdf: false,
                                                        handleFiles(event) {
                                                            let files = event.target.files || event.dataTransfer.files;
                                                            if (files.length > 0) {
                                                                let file = files[0];
                                                                this.fileName = file.name;
                                                                this.isPdf = file.type === 'application/pdf';
                                                                this.previewUrl = this.isPdf ? '' : URL.createObjectURL(file);
                                                            }
                                                        }
                                                    }"
                                                    @click="$refs.fileInput.click()"
                                                    @dragover.prevent="isDragging = true"
                                                    @dragleave.prevent="isDragging = false"
                                                    @drop.prevent="handleFiles($event); isDragging = false"
                                                    :class="isDragging ? 'border-blue-500 bg-blue-50' : ''"
                                                    style="min-height: 300px; max-height: 400px;">

                                                    <!-- Show instructions when no file -->
                                                    <template x-if="!fileName">
                                                        <div>
                                                            <i class="fa-solid fa-upload text-gray-400 text-4xl mb-2"></i>
                                                            <p class="text-gray-500">Drag and drop or click to browse your files</p>
                                                            <p class="text-gray-400 text-sm">Support JPEG, PNG, PDF | Max: 5MB</p>
                                                        </div>
                                                    </template>

                                                    <!-- Image Preview (fixed size) -->
                                                    <template x-if="previewUrl && !isPdf">
                                                        <img :src="previewUrl" class="w-full h-full object-contain rounded-lg" />
                                                    </template>

                                                    <!-- PDF Preview -->
                                                    <template x-if="isPdf">
                                                        <div class="flex flex-col items-center justify-center text-center text-red-600 w-full h-full">
                                                            <i class="fa-solid fa-file-pdf text-5xl mb-2"></i>
                                                            <p class="text-sm font-medium">PDF Selected</p>
                                                            <p class="text-xs text-gray-600" x-text="fileName"></p>
                                                        </div>
                                                    </template>

                                                    <!-- Hidden file input -->
                                                    <input type="file" accept=".jpg,.jpeg,.png,.pdf"
                                                        class="hidden" x-ref="fileInput"
                                                        @change="handleFiles($event)" />
                                                </div>

                                                <!-- Right side: Dynamic form -->
                                                <div class="space-y-4">
                                                    <!-- Document type selector -->
                                                    <div>
                                                        <label class="block text-gray-700 mb-1">Document Type</label>
                                                        <select class="w-full border border-gray-300 rounded-md p-2"
                                                                x-model="docType">
                                                            <option value="">Select document type</option>
                                                            <option value="passport">Passport</option>
                                                            <option value="idvisa">IDs & Visas</option>
                                                            <option value="certificate">Certificate</option>
                                                            <option value="other">Other</option>
                                                        </select>
                                                    </div>

                                                    <!-- Passport -->
                                                    <template x-if="docType === 'passport'">
                                                        <div class="space-y-4">
                                                            <div>
                                                                <label class="block">Passport Number</label>
                                                                <input type="text" class="w-full border p-2 rounded-md">
                                                            </div>
                                                            <div class="grid grid-cols-2 gap-4">
                                                                <div>
                                                                    <label class="block">Issue Date</label>
                                                                    <input type="date" class="w-full border p-2 rounded-md">
                                                                </div>
                                                                <div>
                                                                    <label class="block">Expiry Date</label>
                                                                    <input type="date" class="w-full border p-2 rounded-md">
                                                                </div>
                                                            </div>
                                                            <div>
                                                                <label class="block">Passport Nationality</label>
                                                                <input type="text" class="w-full border p-2 rounded-md">
                                                            </div>
                                                        </div>
                                                    </template>

                                                    <!-- IDs & Visas -->
                                                    <template x-if="docType === 'idvisa'">
                                                        <div class="space-y-4">
                                                            <div>
                                                                <label class="block">What do you want to name this document?</label>
                                                                <select class="w-full border p-2 rounded-md">
                                                                    <option>Schengen visa</option>
                                                                    <option>B1/B2 visa</option>
                                                                    <option>Frontier work permit</option>
                                                                    <option>C1/D visa</option>
                                                                    <option>Driving license</option>
                                                                    <option>Identity card</option>
                                                                </select>
                                                            </div>
                                                            <div>
                                                                <label class="block">Document Number</label>
                                                                <input type="text" class="w-full border p-2 rounded-md">
                                                            </div>
                                                            <div class="grid grid-cols-2 gap-4">
                                                                <div>
                                                                    <label class="block">Issue Date</label>
                                                                    <input type="date" class="w-full border p-2 rounded-md">
                                                                </div>
                                                                <div>
                                                                    <label class="block">Expiry Date</label>
                                                                    <input type="date" class="w-full border p-2 rounded-md">
                                                                </div>
                                                            </div>
                                                            <div>
                                                                <label class="block">Issue Country</label>
                                                                <input type="text" class="w-full border p-2 rounded-md">
                                                            </div>
                                                        </div>
                                                    </template>

                                                    <!-- Certificate -->
                                                    <template x-if="docType === 'certificate'">
                                                        <div class="space-y-5"
                                                            x-data="{ 
                                                                certificateRows: [{ type: '', issue: '', expiry: '' }], 
                                                                certificateTypes: @js($certificateTypes) 
                                                            }"
                                                        >
                                                            <div class="flex items-center justify-between mb-2">
                                                                <!-- Label -->
                                                                <label class="text-sm font-medium text-gray-700">Qualifications</label>

                                                                <!-- Add Certificate Button -->
                                                                <button type="button"
                                                                        class="flex items-center space-x-1 text-[#0053FF] hover:text-blue-700 text-sm font-medium"
                                                                        @click="certificateRows.push({ type:'', issue:'', expiry:'' })">
                                                                    <i class="fa fa-plus-circle"></i>
                                                                    <span>Add Certificate</span>
                                                                </button>
                                                            </div>

                                                            <!-- Dynamic Certificate Rows -->
                                                            <div class="space-y-3">
                                                                <template x-for="(row, index) in certificateRows" :key="index">
                                                                    <div class="border rounded-md p-3 space-y-2">
                                                                        
                                                                        <!-- Searchable Dropdown -->
                                                                        <div x-data="{ open: false, search: '' }" class="relative">
                                                                            <label class="block text-sm">Certificate Type</label>
                                                                            
                                                                            <input 
                                                                                type="text" 
                                                                                x-model="search"
                                                                                @focus="open = true" 
                                                                                @click.away="open = false"
                                                                                placeholder="Search certificate type..."
                                                                                class="w-full border p-2 rounded-md"
                                                                            >

                                                                            <!-- Dropdown list -->
                                                                            <div 
                                                                                x-show="open" 
                                                                                class="absolute z-10 bg-white border w-full mt-1 max-h-40 overflow-y-auto rounded-md shadow-md"
                                                                            >
                                                                                <template 
                                                                                    x-for="type in certificateTypes.filter(t => t.name.toLowerCase().includes(search.toLowerCase()))" 
                                                                                    :key="type.id"
                                                                                >
                                                                                    <div 
                                                                                        @click="row.type = type.id; search = type.name; open = false" 
                                                                                        class="px-3 py-2 hover:bg-blue-100 cursor-pointer"
                                                                                        x-text="type.name"
                                                                                    ></div>
                                                                                </template>
                                                                            </div>
                                                                        </div>

                                                                        <!-- Issue & Expiry Dates -->
                                                                        <div class="grid grid-cols-2 gap-4">
                                                                            <div>
                                                                                <label class="block text-sm">Issue Date</label>
                                                                                <input type="date" x-model="row.issue" class="w-full border p-2 rounded-md">
                                                                            </div>
                                                                            <div>
                                                                                <label class="block text-sm">Expiry Date</label>
                                                                                <input type="date" x-model="row.expiry" class="w-full border p-2 rounded-md">
                                                                            </div>
                                                                        </div>

                                                                        <!-- Remove button -->
                                                                        <div class="flex justify-end">
                                                                            <button type="button"
                                                                                    class="text-[#0053FF] hover:text-red-600"
                                                                                    @click="certificateRows.splice(index,1)">
                                                                                <i class="fa-regular fa-trash-can"></i>
                                                                            </button>
                                                                        </div>
                                                                    </div>
                                                                </template>
                                                            </div>

                                                            <!-- Common Fields -->
                                                            <div>
                                                                <label class="block">Certificate Number</label>
                                                                <input type="text" class="w-full border p-2 rounded-md">
                                                            </div>
                                                            <!-- Certificate Issuer (Searchable Dropdown) -->
                                                            <div x-data="{ open: false, search: '', issuers: @js($certificateIssuers) }" class="relative">
                                                                <label class="block text-sm">Certificate Issuer</label>
                                                                
                                                                <input 
                                                                    type="text" 
                                                                    x-model="search"
                                                                    @focus="open = true" 
                                                                    @click.away="open = false"
                                                                    placeholder="Search certificate issuer..."
                                                                    class="w-full border p-2 rounded-md"
                                                                >

                                                                <!-- Dropdown list -->
                                                                <div 
                                                                    x-show="open" 
                                                                    class="absolute z-10 bg-white border w-full mt-1 max-h-40 overflow-y-auto rounded-md shadow-md"
                                                                >
                                                                    <template 
                                                                        x-for="issuer in issuers.filter(i => i.name.toLowerCase().includes(search.toLowerCase()))" 
                                                                        :key="issuer.id"
                                                                    >
                                                                        <div 
                                                                            @click="search = issuer.name; open = false" 
                                                                            class="px-3 py-2 hover:bg-blue-100 cursor-pointer"
                                                                            x-text="issuer.name"
                                                                        ></div>
                                                                    </template>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </template>


                                                    <!-- Other -->
                                                    <template x-if="docType === 'other'">
                                                        <div class="space-y-4">
                                                            <div>
                                                                <label class="block">What do you want to name this document?</label>
                                                                <select class="w-full border p-2 rounded-md">
                                                                    <option>Reference</option>
                                                                    <option>CV</option>
                                                                </select>
                                                            </div>
                                                            <div class="grid grid-cols-2 gap-4">
                                                                <div>
                                                                    <label class="block">Issue Date</label>
                                                                    <input type="date" class="w-full border p-2 rounded-md">
                                                                </div>
                                                                <div>
                                                                    <label class="block">Expiry Date</label>
                                                                    <input type="date" class="w-full border p-2 rounded-md">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </template>
                                                </div>
                                            </div>

                                            <!-- Buttons -->
                                            <div class="flex justify-end space-x-3 mt-6">
                                                <button  @click="resetForm(); showModal = false" class="px-4 py-2 border rounded-md"> Cancel </button>
                                                <button class="px-4 py-2 bg-[#0053FF] text-white rounded-md"
                                                        x-show="docType !== ''">
                                                    Save
                                                </button>
                                            </div>
                                        </div>
                                    </div>


                                </div>


                                <div class="bg-white rounded-xl p-3 py-8 flex justify-center items-center flex-col">
                                    <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M16.6601 3.36803C12.496 3.19173 9.27886 3.67143 9.27886 3.67143C7.24744 3.81668 3.35443 4.95555 3.35446 11.6067C3.35449 18.2013 3.31139 26.3313 3.35446 29.5723C3.35446 31.5525 4.58049 36.1713 8.82409 36.4188C13.9822 36.7198 23.2732 36.7838 27.5361 36.4188C28.6772 36.3545 32.4764 35.4586 32.9572 31.3251C33.4554 27.043 33.3562 24.067 33.3562 23.3586" stroke="#616161" stroke-width="2.15385" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M36.1356 3.56964C34.1957 1.48046 19.6033 6.59822 19.6154 8.46671C19.629 10.5856 25.3141 11.2374 26.8898 11.6795C27.8374 11.9453 28.0912 12.2179 28.3096 13.2115C29.2992 17.7116 29.796 19.9499 30.9284 19.9999C32.7333 20.0797 38.0289 5.60849 36.1356 3.56964Z" stroke="#0053FE" stroke-width="2.15385" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M27.6322 11.9758L30.7496 8.8584" stroke="#0053FE" stroke-width="2.15385" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M11.6346 21.6943H18.3013" stroke="#616161" stroke-width="2.15385" stroke-linecap="round"/>
                                    <path d="M11.6346 28.3652H24.9679" stroke="#616161" stroke-width="2.15385" stroke-linecap="round"/>
                                    </svg>

                                    <h4 class="mt-2"> Share Document </h4>
                                </div>

                                <div class="bg-white rounded-xl p-3 py-8 flex justify-center items-center flex-col">
                                    <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M5 10C5 7.64298 5 6.46447 5.73223 5.73223C6.46447 5 7.64298 5 10 5C12.357 5 13.5355 5 14.2678 5.73223C15 6.46447 15 7.64298 15 10C15 12.357 15 13.5355 14.2678 14.2678C13.5355 15 12.357 15 10 15C7.64298 15 6.46447 15 5.73223 14.2678C5 13.5355 5 12.357 5 10Z" stroke="#616161" stroke-width="2.15385" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M5 30C5 27.643 5 26.4645 5.73223 25.7322C6.46447 25 7.64298 25 10 25C12.357 25 13.5355 25 14.2678 25.7322C15 26.4645 15 27.643 15 30C15 32.357 15 33.5355 14.2678 34.2678C13.5355 35 12.357 35 10 35C7.64298 35 6.46447 35 5.73223 34.2678C5 33.5355 5 32.357 5 30Z" stroke="#616161" stroke-width="2.15385" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M5 20H15" stroke="#616161" stroke-width="2.15385" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M20 5V13.3333" stroke="#616161" stroke-width="2.15385" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M25 10C25 7.64298 25 6.46447 25.7322 5.73223C26.4645 5 27.643 5 30 5C32.357 5 33.5355 5 34.2678 5.73223C35 6.46447 35 7.64298 35 10C35 12.357 35 13.5355 34.2678 14.2678C33.5355 15 32.357 15 30 15C27.643 15 26.4645 15 25.7322 14.2678C25 13.5355 25 12.357 25 10Z" stroke="#616161" stroke-width="2.15385" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M35 20H25C22.643 20 21.4645 20 20.7322 20.7322C20 21.4645 20 22.643 20 25M20 29.6153V34.2308M25 25V27.5C25 29.9107 26.3062 30 28.3333 30C29.2538 30 30 30.7462 30 31.6667M26.6667 35H25M30 25C32.357 25 33.5355 25 34.2678 25.7333C35 26.4665 35 27.6468 35 30.0072C35 32.3677 35 33.5478 34.2678 34.2812C33.7333 34.8163 32.9612 34.961 31.6667 35" stroke="#0053FE" stroke-width="2.15385" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>

                                    <h4 class="mt-2"> Share Profile </h4>
                                </div>
                            </div>
                            
                            <div class=" flex w-full flex-wrap mt-10">
                                <h3 class="text-lg font-medium w-full text">1 Documents</h3>
                                <div class="grid grid-cols-2 gap-4 w-full mt-3">
                                    <div class="bg-white rounded-xl p-4 flex relative cursor-pointer border border-gray-200 flex items-center " title="Edit Organisation"> 
                                        <div class="flex flex-wrap justify-center w-[80px] h-[90px] items-center p-2 bg-[#E3F2FF] rounded-md ">
                                            <img src="images/passport-img.png" alt="passport" class="">
                                        </div>
                                        <div class="w-[100% - 100px] text-center mb-1 pl-3 flex justify-between items-center" style="width: calc(100% - 100px);">
                                            <div>
                                                <h3 class="text-md w-full font-semibold mb-1 text-left ">Passport</h3>
                                                <span class="text-[12px] text-gray-600 flex"> <img src="images/view-icon.png" > <span class="pl-1">Featured on your Profile Preview </span></span>
                                            </div>
                                            <div class="flex items-center p-2 bg-[#E3F2FF] text-[#0053FF] font-medium flex w-[60px] items-center justify-center rounded-md">
                                                4 <br>
                                                    Yrs
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
</div>
@elserole('super_admin')
    <div class="flex-1 flex flex-col overflow-hidden">
        <div class="flex min-h-screen bg-gray-100">
            <div class="flex-1 transition-all duration-300">
                <main class="p-6 flex-1 overflow-y-auto">
                    <div class="w-full h-screen ">
                        <div class="bg-white p-5 rounded-lg shadow-md">
                            <h2 class="text-xl border-b border-gray-100 font-medium text-[#0053FF] pb-2">Career History</h2>
                            <div class="flex items-center justify-center h-40">
                                <p class="text-gray-500 text-lg font-medium">Career History Coming Soon...</p>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    </div>
@endrole